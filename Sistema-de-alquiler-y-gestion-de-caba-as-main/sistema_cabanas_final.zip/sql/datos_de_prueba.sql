USE pehuen_co;

INSERT INTO usuario (nombre, apellido, dni, telefono, email, nombre_usuario, contrasena, id_rol) VALUES ('Cliente', 'Prueba Uno', '10000001', '2926 400001', 'cliente1@prueba.com', 'cliente1', '$2y$10$7e6sTbHASYiS4bffOZP77Ot7Ykh2N.HptZBVAwJr7PKWzq0hwZ8bS', 2);
INSERT INTO usuario (nombre, apellido, dni, telefono, email, nombre_usuario, contrasena, id_rol) VALUES ('Cliente', 'Prueba Dos', '10000002', '2926 400002', NULL, 'cliente2', '$2y$10$7e6sTbHASYiS4bffOZP77Ot7Ykh2N.HptZBVAwJr7PKWzq0hwZ8bS', 2);
INSERT INTO usuario (nombre, apellido, dni, telefono, email, nombre_usuario, contrasena, id_rol) VALUES ('Cliente', 'Prueba Tres', '10000003', NULL, 'cliente3@prueba.com', 'cliente3', '$2y$10$7e6sTbHASYiS4bffOZP77Ot7Ykh2N.HptZBVAwJr7PKWzq0hwZ8bS', 2);
INSERT INTO usuario (nombre, apellido, dni, telefono, email, nombre_usuario, contrasena, id_rol) VALUES ('Cliente', 'Prueba Cuatro', '10000004', '2926 400004', 'cliente4@prueba.com', 'cliente4', '$2y$10$7e6sTbHASYiS4bffOZP77Ot7Ykh2N.HptZBVAwJr7PKWzq0hwZ8bS', 2);
INSERT INTO usuario (nombre, apellido, dni, telefono, email, nombre_usuario, contrasena, id_rol) VALUES ('Cliente', 'Prueba Cinco', '10000005', '2926 400005', NULL, 'cliente5', '$2y$10$7e6sTbHASYiS4bffOZP77Ot7Ykh2N.HptZBVAwJr7PKWzq0hwZ8bS', 2);

INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana) VALUES ('2026-09-05', '2026-09-10', 'Finalizada', 38000, 190000, 2, 1);
INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana) VALUES ('2026-10-01', '2026-10-04', 'Finalizada', 55000, 165000, 3, 3);
INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana) VALUES ('2026-11-18', '2026-11-25', 'Confirmada', 70000, 490000, 4, 4);
INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana) VALUES ('2026-12-10', '2026-12-15', 'Confirmada', 38000, 190000, 5, 2);
INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana) VALUES ('2026-12-27', '2027-01-03', 'Pendiente', 55000, 385000, 6, 6);
INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana) VALUES ('2027-01-10', '2027-01-14', 'Cancelada', 48000, 192000, 2, 5);
INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana) VALUES ('2026-12-20', '2026-12-23', 'Pendiente', 55000, 165000, 3, 3);

INSERT INTO pago (monto, fecha_hora_pago, metodo_pago, id_reserva) VALUES (100000, '2026-08-20', 'Transferencia', 1);
INSERT INTO pago (monto, fecha_hora_pago, metodo_pago, id_reserva) VALUES (90000, '2026-09-10', 'Efectivo', 1);
INSERT INTO pago (monto, fecha_hora_pago, metodo_pago, id_reserva) VALUES (80000, '2026-09-15', 'Tarjeta', 2);
INSERT INTO pago (monto, fecha_hora_pago, metodo_pago, id_reserva) VALUES (85000, '2026-10-04', 'Efectivo', 2);
INSERT INTO pago (monto, fecha_hora_pago, metodo_pago, id_reserva) VALUES (150000, '2026-11-10', 'Transferencia', 3);
INSERT INTO pago (monto, fecha_hora_pago, metodo_pago, id_reserva) VALUES (60000, '2026-11-15', 'Transferencia', 4);
INSERT INTO pago (monto, fecha_hora_pago, metodo_pago, id_reserva) VALUES (100000, '2026-11-18', 'Efectivo', 3);

INSERT INTO comprobante (ruta_archivo_digital, fecha_carga, id_pago) VALUES ('comprobantes/comprobante_0001.pdf', '2026-08-20', 1);
INSERT INTO comprobante (ruta_archivo_digital, fecha_carga, id_pago) VALUES ('comprobantes/comprobante_0003.pdf', '2026-09-15', 3);
INSERT INTO comprobante (ruta_archivo_digital, fecha_carga, id_pago) VALUES ('comprobantes/comprobante_0005.pdf', '2026-11-10', 5);
INSERT INTO comprobante (ruta_archivo_digital, fecha_carga, id_pago) VALUES ('comprobantes/comprobante_0006.pdf', '2026-11-15', 6);
