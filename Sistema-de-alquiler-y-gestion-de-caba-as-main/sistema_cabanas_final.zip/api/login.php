<?php

include __DIR__ . '/comun.php';

switch (metodo()) {
    case 'POST':
        $d = entrada();
        exigir_campos($d, ['nombre_usuario', 'contrasena']);
        $u = una_fila('SELECT u.id_usuario, u.nombre, u.apellido, u.nombre_usuario, u.contrasena, u.id_rol, r.nombre_rol
                       FROM usuario u JOIN rol r ON r.id_rol = u.id_rol
                       WHERE u.nombre_usuario = ' . texto($d['nombre_usuario']));

        $hash = $u['contrasena'] ?? '$2y$10$1wzoS9RJBjFEcpXdH6Y3XuoPh2tI9HV5PqqRZOPEWvZCYml9Aivc6';
        if (!password_verify((string)$d['contrasena'], $hash) || !$u) {
            fallar('Usuario o contraseña incorrectos.', 401);
        }
        unset($u['contrasena']);
        session_regenerate_id(true);
        $_SESSION['usuario'] = $u;
        responder($u);
    case 'GET':
        responder(exigir_login());
    case 'DELETE':
        $_SESSION = [];
        session_destroy();
        responder(['mensaje' => 'Sesión cerrada.']);
    default:
        metodo_no_permitido();
}
