<?php
include __DIR__ . '/config.php';

mysqli_report(MYSQLI_REPORT_OFF);

$conexion = mysqli_init();
mysqli_options($conexion, MYSQLI_OPT_INT_AND_FLOAT_NATIVE, 1);

if (!mysqli_real_connect($conexion, DB_HOST, DB_USUARIO, DB_CLAVE, DB_NOMBRE, DB_PUERTO)) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    die(json_encode(['error' => 'No se pudo conectar a la base de datos: ' . mysqli_connect_error()]));
}
mysqli_set_charset($conexion, 'utf8mb4');
