<?php

include __DIR__ . '/comun.php';
$usuarioActual = exigir_login();
$esEncargada = es_encargada($usuarioActual);

const SELECT_RESERVA = 'SELECT r.id_reserva, r.fecha_ingreso, r.fecha_egreso, r.estado,
        r.precio_por_noche, r.monto_total AS total,
        COALESCE((SELECT SUM(p.monto) FROM pago p WHERE p.id_reserva = r.id_reserva), 0) AS pagado,
        r.id_usuario AS id_cliente, u.nombre AS cliente_nombre, u.apellido AS cliente_apellido, u.dni AS cliente_dni,
        r.id_cabana, c.nombre_identificador AS cabana
    FROM reserva r
    JOIN usuario u ON u.id_usuario = r.id_usuario
    JOIN cabana c ON c.id_cabana = r.id_cabana';

const ESTADOS = ['Pendiente', 'Confirmada', 'Finalizada', 'Cancelada'];

function completar($r)
{
    $r['total'] = (int)$r['total'];
    $r['pagado'] = (int)$r['pagado'];
    $r['precio_por_noche'] = (int)$r['precio_por_noche'];
    $r['noches'] = noches($r['fecha_ingreso'], $r['fecha_egreso']);
    $vigente = in_array($r['estado'], ['Pendiente', 'Confirmada'], true);

    $r['saldo'] = $r['estado'] === 'Cancelada' ? 0 : $r['total'] - $r['pagado'];
    $r['puede_cobrar'] = $vigente && $r['saldo'] > 0;
    $r['puede_finalizar'] = $r['estado'] === 'Confirmada' && $r['saldo'] === 0 && $r['fecha_egreso'] <= hoy();
    return $r;
}

function leer_reserva($id)
{
    return completar(una_fila(SELECT_RESERVA . ' WHERE r.id_reserva = ' . (int)$id));
}

function validar_fechas($ingreso, $egreso, $actual = null)
{
    if (!es_fecha($ingreso) || !es_fecha($egreso)) {
        fallar('Las fechas deben tener el formato AAAA-MM-DD.');
    }
    if ($egreso <= $ingreso) {
        fallar('La fecha de egreso debe ser posterior a la de ingreso.');
    }
    $ingresoCambia = !$actual || $ingreso !== $actual['fecha_ingreso'];
    if ($ingresoCambia && $ingreso < hoy()) {
        fallar('La fecha de ingreso no puede ser anterior a hoy (' . fecha_ar(hoy()) . ').');
    }
    if ($egreso < hoy()) {
        fallar('La fecha de egreso no puede ser anterior a hoy (' . fecha_ar(hoy()) . ').');
    }
}

function buscar_superposicion($id_cabana, $ingreso, $egreso, $excluir = 0)
{
    return una_fila("SELECT r.fecha_ingreso, r.fecha_egreso, c.nombre_identificador
        FROM reserva r JOIN cabana c ON c.id_cabana = r.id_cabana
        WHERE r.id_cabana = " . (int)$id_cabana . " AND r.estado IN ('Pendiente', 'Confirmada')
          AND r.fecha_ingreso < " . texto($egreso) . ' AND r.fecha_egreso > ' . texto($ingreso) . '
          AND r.id_reserva <> ' . (int)$excluir . '
        ORDER BY r.fecha_ingreso LIMIT 1');
}

function avisar_superposicion($s)
{
    fallar($s['nombre_identificador'] . ' está reservada del ' . fecha_ar($s['fecha_ingreso']) .
        ' al ' . fecha_ar($s['fecha_egreso']) . '. Elegí otras fechas.', 409);
}

function bloquear_cabana($id_cabana)
{
    $c = una_fila('SELECT id_cabana, precio_por_noche FROM cabana WHERE id_cabana = ' . (int)$id_cabana . ' FOR UPDATE');
    if (!$c) {
        fallar('La cabaña no existe.', 404);
    }
    return $c;
}

function total_pagado($id_reserva)
{
    return (int)un_valor('SELECT COALESCE(SUM(monto), 0) FROM pago WHERE id_reserva = ' . (int)$id_reserva);
}

$id = id_param();
switch (metodo()) {
    case 'GET':
        if ($id) {
            $r = una_fila(SELECT_RESERVA . ' WHERE r.id_reserva = ' . $id);
            if (!$r || (!$esEncargada && (int)$r['id_cliente'] !== (int)$usuarioActual['id_usuario'])) {
                fallar('La reserva no existe.', 404);
            }
            responder(completar($r));
        }
        if (!$esEncargada) {
            $_GET['id_cliente'] = $usuarioActual['id_usuario'];
        }
        $where = [];
        if (!empty($_GET['estado'])) {
            if (!in_array($_GET['estado'], ESTADOS, true)) {
                fallar('El estado debe ser: ' . implode(', ', ESTADOS) . '.');
            }
            $where[] = 'r.estado = ' . texto($_GET['estado']);
        }
        foreach (['id_cabana' => 'r.id_cabana', 'id_cliente' => 'r.id_usuario'] as $filtro => $columna) {
            if (!empty($_GET[$filtro])) {
                $n = entero_positivo($_GET[$filtro]);
                if ($n === null) {
                    fallar("El filtro $filtro debe ser un número entero.");
                }
                $where[] = $columna . ' = ' . $n;
            }
        }
        foreach (['desde', 'hasta'] as $f) {
            if (!empty($_GET[$f]) && !es_fecha($_GET[$f])) {
                fallar("La fecha \"$f\" debe tener el formato AAAA-MM-DD.");
            }
        }
        if (!empty($_GET['desde'])) { $where[] = 'r.fecha_egreso > ' . texto($_GET['desde']); }
        if (!empty($_GET['hasta'])) { $where[] = 'r.fecha_ingreso <= ' . texto($_GET['hasta']); }
        $sql = SELECT_RESERVA . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY r.fecha_ingreso, r.id_reserva';
        $lista = [];
        foreach (todas($sql) as $fila) {
            $lista[] = completar($fila);
        }
        responder($lista);

    case 'POST':
        $d = entrada();
        if (!$esEncargada) {
            $d['id_cliente'] = $usuarioActual['id_usuario'];
        }
        exigir_campos($d, ['id_cliente', 'id_cabana', 'fecha_ingreso', 'fecha_egreso']);
        $idCliente = entero_positivo($d['id_cliente']);
        $idCabana = entero_positivo($d['id_cabana']);
        if (!$idCliente || !$idCabana) {
            fallar('El cliente y la cabaña deben ser números válidos.');
        }
        validar_fechas($d['fecha_ingreso'], $d['fecha_egreso']);
        if (!una_fila('SELECT 1 FROM usuario WHERE id_usuario = ' . $idCliente . ' AND id_rol = ' . ROL_CLIENTE)) {
            fallar('El cliente no existe.', 404);
        }

        empezar_transaccion();
        $cabana = bloquear_cabana($idCabana);
        if ($s = buscar_superposicion($idCabana, $d['fecha_ingreso'], $d['fecha_egreso'])) {
            avisar_superposicion($s);
        }

        $precio = (int)$cabana['precio_por_noche'];
        $total = noches($d['fecha_ingreso'], $d['fecha_egreso']) * $precio;
        consulta("INSERT INTO reserva (fecha_ingreso, fecha_egreso, estado, precio_por_noche, monto_total, id_usuario, id_cabana)
                  VALUES (" . texto($d['fecha_ingreso']) . ', ' . texto($d['fecha_egreso']) . ", 'Pendiente', "
                  . $precio . ', ' . $total . ', ' . $idCliente . ', ' . $idCabana . ')');
        $nueva = id_nuevo();
        terminar_transaccion();
        responder(leer_reserva($nueva), 201);

    case 'PUT':
        if (!$id) fallar('Falta el id de la reserva.');
        $d = entrada();
        $accion = $d['accion'] ?? null;

        if ($accion === 'cancelar') {
            $actual = una_fila('SELECT id_usuario, estado FROM reserva WHERE id_reserva = ' . $id);
            if (!$actual || (!$esEncargada && (int)$actual['id_usuario'] !== (int)$usuarioActual['id_usuario'])) {
                fallar('La reserva no existe.', 404);
            }

            consulta("UPDATE reserva SET estado = 'Cancelada' WHERE id_reserva = " . $id . " AND estado IN ('Pendiente', 'Confirmada')");
            if (!filas_afectadas()) {
                fallar('No se puede cancelar una reserva ' . $actual['estado'] . '.', 409);
            }
            responder(['id_reserva' => $id, 'estado' => 'Cancelada']);
        }

        exigir_encargada();
        $previa = una_fila('SELECT id_cabana FROM reserva WHERE id_reserva = ' . $id);
        if (!$previa) {
            fallar('La reserva no existe.', 404);
        }

        if ($accion === 'finalizar') {
            empezar_transaccion();
            $r = una_fila('SELECT estado, fecha_egreso, monto_total FROM reserva WHERE id_reserva = ' . $id . ' FOR UPDATE');
            if ($r['estado'] !== 'Confirmada') {
                fallar('Solo se puede finalizar una reserva Confirmada (esta está ' . $r['estado'] . ').', 409);
            }
            $saldo = (int)$r['monto_total'] - total_pagado($id);
            if ($saldo > 0) {
                fallar('No se puede finalizar: la reserva tiene un saldo pendiente de ' . pesos($saldo) . '. Tiene que estar saldada.', 409);
            }
            if ($r['fecha_egreso'] > hoy()) {
                fallar('No se puede finalizar antes de la fecha de egreso (' . fecha_ar($r['fecha_egreso']) . ').', 409);
            }
            consulta("UPDATE reserva SET estado = 'Finalizada' WHERE id_reserva = " . $id);
            terminar_transaccion();
            responder(['id_reserva' => $id, 'estado' => 'Finalizada']);
        }
        if ($accion !== null) {
            fallar('Acción desconocida: "' . $accion . '".');
        }

        $cabanaNueva = isset($d['id_cabana']) ? entero_positivo($d['id_cabana']) : (int)$previa['id_cabana'];
        if (!$cabanaNueva) {
            fallar('La cabaña debe ser un número válido.');
        }
        empezar_transaccion();
        $cabana = bloquear_cabana($cabanaNueva);
        $actual = una_fila('SELECT * FROM reserva WHERE id_reserva = ' . $id . ' FOR UPDATE');
        if (!in_array($actual['estado'], ['Pendiente', 'Confirmada'], true)) {
            fallar('Una reserva ' . $actual['estado'] . ' no se puede modificar.', 409);
        }
        $ingreso = $d['fecha_ingreso'] ?? $actual['fecha_ingreso'];
        $egreso = $d['fecha_egreso'] ?? $actual['fecha_egreso'];
        validar_fechas($ingreso, $egreso, $actual);

        $cambiaCabana = (int)$actual['id_cabana'] !== $cabanaNueva;
        if ($cambiaCabana && $actual['fecha_ingreso'] < hoy()) {
            fallar('No se puede cambiar de cabaña una reserva cuya estadía ya empezó.', 409);
        }
        if ($s = buscar_superposicion($cabanaNueva, $ingreso, $egreso, $id)) {
            avisar_superposicion($s);
        }

        $precio = $cambiaCabana ? (int)$cabana['precio_por_noche'] : (int)$actual['precio_por_noche'];
        $total = noches($ingreso, $egreso) * $precio;

        $pagado = total_pagado($id);
        if ($pagado > $total) {
            fallar('No se pueden cambiar las fechas así: ya se cobraron ' . pesos($pagado) . ' y el nuevo total sería ' .
                pesos($total) . '. Elegí fechas cuyo total sea al menos lo ya pagado.', 409);
        }
        consulta('UPDATE reserva SET fecha_ingreso = ' . texto($ingreso) . ', fecha_egreso = ' . texto($egreso)
                 . ', id_cabana = ' . $cabanaNueva . ', precio_por_noche = ' . $precio . ', monto_total = ' . $total
                 . ' WHERE id_reserva = ' . $id);
        terminar_transaccion();
        responder(leer_reserva($id));

    default:
        metodo_no_permitido();
}
