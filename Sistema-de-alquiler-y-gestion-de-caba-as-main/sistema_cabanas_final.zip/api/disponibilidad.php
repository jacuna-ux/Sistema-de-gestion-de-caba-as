<?php

include __DIR__ . '/comun.php';
exigir_login();
if (metodo() !== 'GET') metodo_no_permitido();

$ingreso = $_GET['ingreso'] ?? '';
$egreso = $_GET['egreso'] ?? '';
if (!es_fecha($ingreso) || !es_fecha($egreso)) {
    fallar('Indicá ingreso y egreso con el formato AAAA-MM-DD.');
}
if ($egreso <= $ingreso) {
    fallar('La fecha de egreso debe ser posterior a la de ingreso.');
}

$cabanas = todas('SELECT * FROM cabana ORDER BY id_cabana');
$choques = todas("SELECT id_reserva, id_cabana, fecha_ingreso, fecha_egreso, estado FROM reserva
    WHERE estado IN ('Pendiente', 'Confirmada') AND fecha_ingreso < " . texto($egreso) . ' AND fecha_egreso > ' . texto($ingreso) . '
    ORDER BY fecha_ingreso');

$porCabana = [];
foreach ($choques as $r) {
    $porCabana[$r['id_cabana']][] = $r;
}
$libres = [];
$ocupadas = [];
foreach ($cabanas as $c) {
    if (empty($porCabana[$c['id_cabana']])) {
        $libres[] = $c;
    } else {
        $c['reservas'] = $porCabana[$c['id_cabana']];
        if (!es_encargada()) {
            foreach ($c['reservas'] as $i => $rr) {
                unset($c['reservas'][$i]['id_reserva']);
            }
        }
        $ocupadas[] = $c;
    }
}
responder(['ingreso' => $ingreso, 'egreso' => $egreso, 'noches' => noches($ingreso, $egreso),
           'libres' => $libres, 'ocupadas' => $ocupadas]);
