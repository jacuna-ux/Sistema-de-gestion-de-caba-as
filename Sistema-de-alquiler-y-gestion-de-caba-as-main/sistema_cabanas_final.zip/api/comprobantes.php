<?php

include __DIR__ . '/comun.php';
$usuarioActual = exigir_login();
if (metodo() !== 'GET') metodo_no_permitido();

$soloMios = '';
if (!es_encargada($usuarioActual)) {
    $soloMios = ' AND r.id_usuario = ' . (int)$usuarioActual['id_usuario'];
}

$sql = 'SELECT cp.id_comprobante, cp.ruta_archivo_digital, cp.fecha_carga,
               p.id_pago, p.monto, p.fecha_hora_pago, p.metodo_pago,
               r.id_reserva, r.fecha_ingreso, r.fecha_egreso,
               u.nombre AS cliente_nombre, u.apellido AS cliente_apellido, u.dni AS cliente_dni,
               c.nombre_identificador AS cabana
        FROM comprobante cp
        JOIN pago p ON p.id_pago = cp.id_pago
        JOIN reserva r ON r.id_reserva = p.id_reserva
        JOIN usuario u ON u.id_usuario = r.id_usuario
        JOIN cabana c ON c.id_cabana = r.id_cabana';

if ($id = id_param()) {
    $x = una_fila($sql . ' WHERE cp.id_comprobante = ' . $id . $soloMios);
    $x ? responder($x) : fallar('El comprobante no existe.', 404);
}
if (!empty($_GET['id_pago'])) {
    $idPago = entero_positivo($_GET['id_pago']);
    if ($idPago === null) {
        fallar('El filtro id_pago debe ser un número entero.');
    }
    responder(todas($sql . ' WHERE cp.id_pago = ' . $idPago . $soloMios));
}
responder(todas($sql . ' WHERE 1 = 1' . $soloMios . ' ORDER BY cp.id_comprobante'));
