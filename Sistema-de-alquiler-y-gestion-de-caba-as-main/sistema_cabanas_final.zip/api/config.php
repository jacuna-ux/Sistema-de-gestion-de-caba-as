<?php

const DB_HOST = 'localhost';
const DB_USUARIO = 'root';
const DB_CLAVE = '';
const DB_NOMBRE = 'pehuen_co';
const DB_PUERTO = 3306;

const ROL_ENCARGADA = 1;
const ROL_CLIENTE = 2;
