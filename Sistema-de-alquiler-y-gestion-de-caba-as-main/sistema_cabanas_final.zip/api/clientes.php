<?php

include __DIR__ . '/comun.php';
exigir_encargada();

const CAMPOS_CLIENTE = 'id_usuario AS id_cliente, nombre, apellido, dni, telefono, email';
$id = id_param();

switch (metodo()) {
    case 'GET':
        if ($id) {
            $c = una_fila('SELECT ' . CAMPOS_CLIENTE . ' FROM usuario WHERE id_usuario = ' . $id . ' AND id_rol = ' . ROL_CLIENTE);
            $c ? responder($c) : fallar('El cliente no existe.', 404);
        }
        if (!empty($_GET['dni'])) {
            $c = una_fila('SELECT ' . CAMPOS_CLIENTE . ' FROM usuario WHERE dni = ' . texto($_GET['dni']) . ' AND id_rol = ' . ROL_CLIENTE);
            $c ? responder($c) : fallar('No hay un cliente con ese DNI.', 404);
        }
        responder(todas('SELECT ' . CAMPOS_CLIENTE . ' FROM usuario WHERE id_rol = ' . ROL_CLIENTE . ' ORDER BY apellido, nombre'));

    case 'POST':

        responder(crear_cliente(entrada()) + ['mensaje' => 'Cliente registrado.'], 201);

    case 'PUT':
        if (!$id) fallar('Falta el id del cliente.');
        $d = entrada();
        if (!una_fila('SELECT 1 FROM usuario WHERE id_usuario = ' . $id . ' AND id_rol = ' . ROL_CLIENTE)) {
            fallar('El cliente no existe.', 404);
        }
        if (($d['accion'] ?? null) === 'restablecer_clave') {
            responder(['contrasena_generada' => cambiar_clave($id), 'mensaje' => 'Contraseña restablecida.']);
        }
        validar_cliente($d);
        $sql = 'UPDATE usuario SET nombre = ' . texto($d['nombre']) . ', apellido = ' . texto($d['apellido'])
            . ', dni = ' . texto($d['dni']) . ', telefono = ' . texto($d['telefono'] ?? null)
            . ', email = ' . texto($d['email'] ?? null) . ' WHERE id_usuario = ' . $id;
        if (!intentar($sql)) {
            fallar_por_error(MENSAJES_DUPLICADO_USUARIO);
        }
        if (!empty($d['contrasena'])) {
            cambiar_clave($id, $d['contrasena']);
        }
        responder(['mensaje' => 'Cliente modificado.']);

    case 'DELETE':
        if (!$id) fallar('Falta el id del cliente.');
        if (!intentar('DELETE FROM usuario WHERE id_usuario = ' . $id . ' AND id_rol = ' . ROL_CLIENTE)) {

            if (es_error_clave_foranea()) {
                fallar('No se puede eliminar: el cliente tiene reservas registradas.', 409);
            }
            fallar_por_error();
        }
        filas_afectadas() ? responder(['mensaje' => 'Cliente eliminado.']) : fallar('El cliente no existe.', 404);

    default:
        metodo_no_permitido();
}
