<?php

header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('America/Argentina/Buenos_Aires');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();
include __DIR__ . '/conexion.php';

$en_transaccion = false;

function responder($datos, $codigo = 200)
{
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fallar($mensaje, $codigo = 400)
{
    global $conexion, $en_transaccion;
    if ($en_transaccion) {
        mysqli_rollback($conexion);
        $en_transaccion = false;
    }
    responder(['error' => $mensaje], $codigo);
}

function entrada()
{
    $datos = json_decode(file_get_contents('php://input'), true);
    return is_array($datos) ? $datos : [];
}

function metodo()
{
    return $_SERVER['REQUEST_METHOD'];
}

function metodo_no_permitido()
{
    fallar('Método no permitido.', 405);
}

function exigir_campos($datos, $campos)
{
    foreach ($campos as $c) {
        if (!isset($datos[$c]) || trim((string)$datos[$c]) === '') {
            fallar("Falta completar el campo $c.");
        }
    }
}

function es_fecha($texto)
{
    $f = DateTime::createFromFormat('Y-m-d', (string)$texto);
    return $f && $f->format('Y-m-d') === $texto;
}

function hoy()
{
    return date('Y-m-d');
}

function mas_un_dia($fecha)
{
    return date('Y-m-d', strtotime($fecha . ' +1 day'));
}

function noches($ingreso, $egreso)
{
    return (int)round((strtotime($egreso) - strtotime($ingreso)) / 86400);
}

function fecha_ar($f)
{
    return date('d/m/Y', strtotime($f));
}

function pesos($n)
{
    return '$ ' . number_format((int)$n, 0, ',', '.');
}

function entero_positivo($valor)
{
    $n = filter_var($valor, FILTER_VALIDATE_INT);
    return ($n === false || $n < 1) ? null : $n;
}

function id_param()
{
    $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT);
    return $id === false ? null : $id;
}

function texto($valor)
{
    global $conexion;
    if ($valor === null || trim((string)$valor) === '') {
        return 'NULL';
    }
    return "'" . mysqli_real_escape_string($conexion, trim((string)$valor)) . "'";
}

function consulta($sql)
{
    global $conexion;
    $r = mysqli_query($conexion, $sql);
    if ($r === false) {
        error_log('SQL: ' . mysqli_error($conexion) . ' -> ' . $sql);
        fallar('Error interno del servidor.', 500);
    }
    return $r;
}

function intentar($sql)
{
    global $conexion;
    return mysqli_query($conexion, $sql);
}

function una_fila($sql)
{
    $fila = mysqli_fetch_assoc(consulta($sql));
    return $fila ?: null;
}

function todas($sql)
{
    $filas = [];
    $resultado = consulta($sql);
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $filas[] = $fila;
    }
    return $filas;
}

function un_valor($sql)
{
    $fila = mysqli_fetch_row(consulta($sql));
    return $fila ? $fila[0] : null;
}

function id_nuevo()
{
    global $conexion;
    return (int)mysqli_insert_id($conexion);
}

function filas_afectadas()
{
    global $conexion;
    return (int)mysqli_affected_rows($conexion);
}

function empezar_transaccion()
{
    global $conexion, $en_transaccion;
    mysqli_begin_transaction($conexion);
    $en_transaccion = true;
}

function terminar_transaccion()
{
    global $conexion, $en_transaccion;
    mysqli_commit($conexion);
    $en_transaccion = false;
}

function fallar_por_error($mensajes = [])
{
    global $conexion;
    $codigo = mysqli_errno($conexion);
    $detalle = mysqli_error($conexion);
    if ($codigo == 1062) {
        $clave = preg_match("/for key '([^']+)'/", $detalle, $m) ? $m[1] : '';
        foreach ($mensajes as $texto => $mensaje) {
            if (stripos($clave, $texto) !== false) {
                fallar($mensaje, 409);
            }
        }
        fallar('Ya existe un registro con esos datos.', 409);
    }
    error_log('SQL: ' . $detalle);
    fallar('Error interno del servidor.', 500);
}

function es_error_clave_foranea()
{
    global $conexion;
    return in_array(mysqli_errno($conexion), [1451, 1452]);
}

function exigir_login()
{
    if (empty($_SESSION['usuario'])) {
        fallar('Tenés que iniciar sesión.', 401);
    }
    return $_SESSION['usuario'];
}

function es_encargada($u = null)
{
    $u = $u ?: ($_SESSION['usuario'] ?? null);
    return $u && (int)$u['id_rol'] === ROL_ENCARGADA;
}

function exigir_encargada()
{
    $u = exigir_login();
    if (!es_encargada($u)) {
        fallar('Solo la encargada puede hacer esto.', 403);
    }
    return $u;
}

function validar_cliente($d)
{
    exigir_campos($d, ['nombre', 'apellido', 'dni']);
    if (!preg_match('/^\d{7,9}$/', (string)$d['dni'])) {
        fallar('El DNI debe tener entre 7 y 9 números, sin puntos.');
    }
    if (!empty($d['email']) && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) {
        fallar('El email no es válido.');
    }
    if (isset($d['contrasena']) && $d['contrasena'] !== '' && strlen($d['contrasena']) < 6) {
        fallar('La contraseña debe tener al menos 6 caracteres.');
    }
}

const MENSAJES_DUPLICADO_USUARIO = [
    'nombre_usuario' => 'Ese nombre de usuario ya está en uso.',
    'dni' => 'Ya existe una persona registrada con ese DNI.',
];

function generar_clave()
{
    $letras = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $clave = '';
    for ($i = 0; $i < 10; $i++) {
        $clave .= $letras[random_int(0, strlen($letras) - 1)];
    }
    return $clave;
}

function crear_cliente($d)
{
    validar_cliente($d);
    $nombreUsuario = trim($d['nombre_usuario'] ?? '') !== '' ? trim($d['nombre_usuario']) : $d['dni'];
    $generada = empty($d['contrasena']);
    $clave = $generada ? generar_clave() : $d['contrasena'];
    $hash = password_hash($clave, PASSWORD_DEFAULT);

    $sql = 'INSERT INTO usuario (nombre, apellido, dni, telefono, email, nombre_usuario, contrasena, id_rol) VALUES ('
        . texto($d['nombre']) . ', ' . texto($d['apellido']) . ', ' . texto($d['dni']) . ', '
        . texto($d['telefono'] ?? null) . ', ' . texto($d['email'] ?? null) . ', '
        . texto($nombreUsuario) . ', ' . texto($hash) . ', ' . ROL_CLIENTE . ')';
    if (!intentar($sql)) {

        $mensajes = trim($d['nombre_usuario'] ?? '') === ''
            ? ['nombre_usuario' => MENSAJES_DUPLICADO_USUARIO['dni'], 'dni' => MENSAJES_DUPLICADO_USUARIO['dni']]
            : MENSAJES_DUPLICADO_USUARIO;
        fallar_por_error($mensajes);
    }
    return ['id_cliente' => id_nuevo(), 'nombre_usuario' => $nombreUsuario,
            'contrasena_generada' => $generada ? $clave : null];
}

function cambiar_clave($id, $nueva = null)
{
    $generada = $nueva === null || $nueva === '';
    $clave = $generada ? generar_clave() : $nueva;
    consulta('UPDATE usuario SET contrasena = ' . texto(password_hash($clave, PASSWORD_DEFAULT)) .
             ' WHERE id_usuario = ' . (int)$id . ' AND id_rol = ' . ROL_CLIENTE);
    return $generada ? $clave : null;
}
