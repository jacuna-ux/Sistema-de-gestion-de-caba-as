<?php

include __DIR__ . '/comun.php';
if (metodo() !== 'POST') metodo_no_permitido();

$d = entrada();
exigir_campos($d, ['nombre_usuario', 'contrasena']);
$nuevo = crear_cliente($d);
$u = una_fila('SELECT u.id_usuario, u.nombre, u.apellido, u.nombre_usuario, u.id_rol, r.nombre_rol
               FROM usuario u JOIN rol r ON r.id_rol = u.id_rol WHERE u.id_usuario = ' . $nuevo['id_cliente']);
session_regenerate_id(true);
$_SESSION['usuario'] = $u;
responder($u, 201);
