<?php

include __DIR__ . '/comun.php';

function validar_cabana($d)
{
    exigir_campos($d, ['nombre_identificador', 'capacidad_maxima', 'precio_por_noche']);
    if (filter_var($d['capacidad_maxima'], FILTER_VALIDATE_INT) === false || $d['capacidad_maxima'] < 1) {
        fallar('La capacidad máxima debe ser un número entero mayor a 0.');
    }
    if (filter_var($d['precio_por_noche'], FILTER_VALIDATE_INT) === false || $d['precio_por_noche'] < 0) {
        fallar('El precio por noche debe ser un número entero, sin negativos.');
    }
}

const MENSAJE_DUPLICADO_CABANA = ['nombre' => 'Ya existe una cabaña con ese nombre.'];

$id = id_param();
switch (metodo()) {
    case 'GET':
        if ($id) {
            $c = una_fila('SELECT * FROM cabana WHERE id_cabana = ' . $id);
            $c ? responder($c) : fallar('La cabaña no existe.', 404);
        }
        responder(todas('SELECT * FROM cabana ORDER BY id_cabana'));

    case 'POST':
        exigir_encargada();
        $d = entrada();
        validar_cabana($d);

        $sql = 'INSERT INTO cabana (nombre_identificador, capacidad_maxima, descripcion_equipamiento, precio_por_noche) VALUES ('
            . texto($d['nombre_identificador']) . ', ' . (int)$d['capacidad_maxima'] . ', '
            . texto($d['descripcion_equipamiento'] ?? null) . ', ' . (int)$d['precio_por_noche'] . ')';
        if (!intentar($sql)) {
            fallar_por_error(MENSAJE_DUPLICADO_CABANA);
        }
        responder(['id_cabana' => id_nuevo(), 'mensaje' => 'Cabaña creada.'], 201);

    case 'PUT':
        exigir_encargada();
        if (!$id) fallar('Falta el id de la cabaña.');
        $d = entrada();
        validar_cabana($d);
        if (!una_fila('SELECT 1 FROM cabana WHERE id_cabana = ' . $id)) {
            fallar('La cabaña no existe.', 404);
        }

        $sql = 'UPDATE cabana SET nombre_identificador = ' . texto($d['nombre_identificador'])
            . ', capacidad_maxima = ' . (int)$d['capacidad_maxima']
            . ', descripcion_equipamiento = ' . texto($d['descripcion_equipamiento'] ?? null)
            . ', precio_por_noche = ' . (int)$d['precio_por_noche'] . ' WHERE id_cabana = ' . $id;
        if (!intentar($sql)) {
            fallar_por_error(MENSAJE_DUPLICADO_CABANA);
        }
        responder(['mensaje' => 'Cabaña modificada.']);

    case 'DELETE':
        exigir_encargada();
        if (!$id) fallar('Falta el id de la cabaña.');
        if (!intentar('DELETE FROM cabana WHERE id_cabana = ' . $id)) {

            if (es_error_clave_foranea()) {
                fallar('No se puede eliminar: la cabaña tiene reservas registradas.', 409);
            }
            fallar_por_error();
        }
        filas_afectadas() ? responder(['mensaje' => 'Cabaña eliminada.']) : fallar('La cabaña no existe.', 404);

    default:
        metodo_no_permitido();
}
